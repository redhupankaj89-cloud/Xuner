package com.xuner.app;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView result;
    private TextToSpeech tts;
    private static final int VOICE = 10;
    private static final int MIC = 11;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40, 60, 40, 40);
        box.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Xuner");
        title.setTextSize(34);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Your simple voice assistant");
        sub.setTextSize(17);
        sub.setGravity(Gravity.CENTER);
        box.addView(sub);

        Button speak = new Button(this);
        speak.setText("🎙 Speak to Xuner");
        box.addView(speak);

        result = new TextView(this);
        result.setText("Tap the button and speak.");
        result.setTextSize(18);
        result.setPadding(0, 35, 0, 0);
        box.addView(result);

        setContentView(box);

        tts = new TextToSpeech(this, s -> { if (s == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault()); });

        speak.setOnClickListener(v -> startVoice());
    }

    private void startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC);
            return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye...");
        startActivityForResult(i, VOICE);
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == VOICE && c == RESULT_OK && d != null) {
            ArrayList<String> x = d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (x != null && !x.isEmpty()) {
                String text = x.get(0);
                result.setText("You: " + text);
                if (tts != null) tts.speak("Aapne kaha " + text, TextToSpeech.QUEUE_FLUSH, null, "xuner");
            }
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
