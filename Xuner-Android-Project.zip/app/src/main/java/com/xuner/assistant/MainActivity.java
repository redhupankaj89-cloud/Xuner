package com.xuner.assistant;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout chat;
    EditText input;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        addBot("Hi Bro! 👋 Main Xuner hoon. Simple Hindi/Hinglish mein baat kar sakte ho.");
    }

    TextView tv(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setPadding(18,14,18,14);
        return t;
    }

    void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        TextView bar = tv("✨  Xuner", 22); bar.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(bar, new LinearLayout.LayoutParams(-1,70));

        ScrollView sv = new ScrollView(this);
        chat = new LinearLayout(this); chat.setOrientation(LinearLayout.VERTICAL);
        sv.addView(chat); root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout row = new LinearLayout(this);
        input = new EditText(this); input.setHint("Type a message...");
        Button send = new Button(this); send.setText("Send");
        Button mic = new Button(this); mic.setText("🎙");
        row.addView(input, new LinearLayout.LayoutParams(0,70,1));
        row.addView(mic, new LinearLayout.LayoutParams(75,70));
        row.addView(send, new LinearLayout.LayoutParams(90,70));
        root.addView(row);

        send.setOnClickListener(v -> sendText());
        mic.setOnClickListener(v -> voice());
        setContentView(root);
    }

    void addUser(String s) { TextView t=tv("You: "+s,17); chat.addView(t); }
    void addBot(String s) { TextView t=tv("Xuner: "+s,17); chat.addView(t); }

    void sendText() {
        String s=input.getText().toString().trim();
        if(s.isEmpty()) return;
        addUser(s); input.setText("");
        String q=s.toLowerCase(Locale.ROOT);
        if(q.contains("hello")||q.contains("hi")||q.contains("namaste"))
            addBot("Namaste Bro! 😊 Batao kya karna hai?");
        else if(q.contains("kaun") && q.contains("ho"))
            addBot("Main Xuner hoon — tumhara personal AI assistant.");
        else if(q.contains("time"))
            addBot("Main phone ka exact current time directly nahi dekh raha. Status bar se time check kar lo.");
        else
            addBot("Samajh gaya Bro. Is starter APK mein local assistant active hai. Real AI replies ke liye AI API key/backend connect karna hoga.");
    }

    void voice() {
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10); return;
        }
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        try { startActivityForResult(i, 11); } catch(Exception e) { addBot("Voice recognition available nahi hai."); }
    }

    @Override protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d);
        if(r==11 && c==RESULT_OK && d!=null) {
            ArrayList<String> a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(a!=null && !a.isEmpty()) { input.setText(a.get(0)); sendText(); }
        }
    }
}
