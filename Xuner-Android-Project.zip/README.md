# Xuner Android APK

Starter Android assistant with:
- Xuner branding
- Hindi/Hinglish chat UI
- Android voice input
- Local starter responses
- GitHub Actions cloud APK build

The app is intentionally a starter: a production AI backend/API key still needs to be connected for real model responses.
