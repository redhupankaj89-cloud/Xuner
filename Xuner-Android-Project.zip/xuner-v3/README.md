# Xuner Real AI v3

Android voice/chat assistant for personal use.

Features:
- Hindi/Hinglish voice input
- OpenAI Responses API integration
- GPT-5.6 Luna model
- Hindi/Hinglish spoken replies
- Xuner/Bro personality
- API key entered in-app and stored locally

Security note: a client-side API key is not a production-secure architecture. Do not publish/share an APK containing your key. For a public app, use a backend proxy with the key stored server-side.
