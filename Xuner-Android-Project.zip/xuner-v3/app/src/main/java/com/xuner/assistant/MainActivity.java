package com.xuner.assistant;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.content.pm.PackageManager;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout chat;
    private EditText input;
    private TextToSpeech tts;
    private android.content.SharedPreferences prefs;
    private static final String PREFS="xuner_settings";
    private static final String API_KEY="api_key";
    private static final String MODEL="gpt-5.6-luna";
    private static final String API_URL="https://api.openai.com/v1/responses";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        tts=new TextToSpeech(this,status -> { if(status==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi","IN")); });
        buildUi();
        addBot("Namaste Bro 👋 Main Xuner hoon. Mujhse text ya 🎙️ voice mein baat karo. AI use karne ke liye ⚙ mein API key save karo.");
    }

    private TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(22,16,22,16); return t; }

    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=tv("🤖  Xuner AI",22);
        Button settings=new Button(this); settings.setText("⚙");
        head.addView(title,new LinearLayout.LayoutParams(0,72,1)); head.addView(settings,new LinearLayout.LayoutParams(76,72)); root.addView(head);
        TextView sub=tv("Real AI • Hindi/Hinglish • Voice",14); root.addView(sub);
        ScrollView sv=new ScrollView(this); chat=new LinearLayout(this); chat.setOrientation(LinearLayout.VERTICAL); sv.addView(chat); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout row=new LinearLayout(this);
        input=new EditText(this); input.setHint("Bro, kuch bhi pucho...");
        Button mic=new Button(this); mic.setText("🎙️"); Button send=new Button(this); send.setText("Send");
        row.addView(input,new LinearLayout.LayoutParams(0,76,1)); row.addView(mic,new LinearLayout.LayoutParams(78,76)); row.addView(send,new LinearLayout.LayoutParams(96,76)); root.addView(row);
        send.setOnClickListener(v->sendText()); mic.setOnClickListener(v->voice()); settings.setOnClickListener(v->showApiKeyDialog());
        setContentView(root);
    }

    private void addUser(String s){ chat.addView(tv("You: "+s,17)); }
    private void addBot(String s){ chat.addView(tv("Xuner: "+s,17)); }

    private void sendText(){
        String s=input.getText().toString().trim(); if(s.isEmpty()) return;
        addUser(s); input.setText("");
        String key=prefs.getString(API_KEY,"").trim();
        if(key.isEmpty()){ addBot("Bro, ⚙ par tap karke apni OpenAI API key save karo. API key ko GitHub mein mat daalna."); return; }
        addBot("Soch raha hoon... 🤖");
        new Thread(()->{
            String answer=callAI(key,s);
            runOnUiThread(()->{ if(chat.getChildCount()>0) chat.removeViewAt(chat.getChildCount()-1); addBot(answer); speak(answer); });
        }).start();
    }

    private String callAI(String key,String userText){
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(API_URL).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Authorization","Bearer "+key);
            JSONObject body=new JSONObject(); body.put("model",MODEL); body.put("input",new JSONArray().put(new JSONObject().put("role","developer").put("content","You are Xuner, a personal AI assistant. Call the user Bro. Reply in simple Hindi/Hinglish, short and practical. Give steps one by one when asked. Ask before important actions. Never claim to have done an action you cannot actually perform." )).put(new JSONObject().put("role","user").put("content",userText)));
            OutputStream os=c.getOutputStream(); os.write(body.toString().getBytes("UTF-8")); os.close();
            int code=c.getResponseCode(); InputStream is=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
            BufferedReader br=new BufferedReader(new InputStreamReader(is,"UTF-8")); StringBuilder sb=new StringBuilder(); String line; while((line=br.readLine())!=null) sb.append(line); br.close();
            JSONObject res=new JSONObject(sb.toString());
            if(code<200||code>=300){ JSONObject e=res.optJSONObject("error"); return "Bro, API error: "+(e==null?"Request failed":e.optString("message","Request failed")); }
            String out=res.optString("output_text",""); if(out.isEmpty()) out=extract(res); return out.isEmpty()?"Bro, AI ne reply nahi diya.":out.trim();
        }catch(Exception e){ return "Bro, AI connection error. Internet aur API key check karo."; }
        finally{ if(c!=null)c.disconnect(); }
    }

    private String extract(JSONObject res)throws JSONException{
        JSONArray out=res.optJSONArray("output"); if(out==null)return ""; StringBuilder sb=new StringBuilder();
        for(int i=0;i<out.length();i++){ JSONObject item=out.optJSONObject(i); if(item==null)continue; JSONArray content=item.optJSONArray("content"); if(content==null)continue;
            for(int j=0;j<content.length();j++){ JSONObject p=content.optJSONObject(j); if(p==null)continue; String s=p.optString("text",""); if(!s.isEmpty()){ if(sb.length()>0)sb.append("\n"); sb.append(s); } }
        } return sb.toString();
    }

    private void showApiKeyDialog(){
        final EditText key=new EditText(this); key.setHint("OpenAI API key"); key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); key.setText(prefs.getString(API_KEY,""));
        LinearLayout box=new LinearLayout(this); box.setPadding(30,5,30,5); box.addView(key,new LinearLayout.LayoutParams(-1,72));
        new android.app.AlertDialog.Builder(this).setTitle("Xuner AI API Key").setMessage("Key sirf is phone par save hogi. Public GitHub/APK mein API key mat rakho.").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->prefs.edit().putString(API_KEY,key.getText().toString().trim()).apply()).show();
    }

    private void speak(String s){ try{ if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"xuner"); }catch(Exception ignored){} }

    private void voice(){
        if(android.os.Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10); return; }
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN"); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Bro, bolo...");
        try{ startActivityForResult(i,11); }catch(Exception e){ addBot("Bro, voice recognition available nahi hai."); }
    }

    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==11&&c==RESULT_OK&&d!=null){ ArrayList<String>a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if(a!=null&&!a.isEmpty()){ input.setText(a.get(0)); sendText(); } } }
    @Override protected void onDestroy(){ if(tts!=null)tts.shutdown(); super.onDestroy(); }
}
